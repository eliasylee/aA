class HumanPlayer

  def initialize(name = "Christian")
    @name = name
  end

  def get_guess
    gets.chomp.to_i
  end

  def prompt
    puts "Please enter your guess #{@name}"
  end



end
