require_relative 'board.rb'
require_relative 'humanplayer.rb'
require_relative 'card.rb'
require_relative 'ComputerPlayer.rb'
require 'byebug'

class Game
  attr_reader :previous_guess, :game_board

  def initialize
    @game_board = Board.new(4)
    @game_board.populate
    @previous_guess = previous_guess
    @players = []
    @players << HumanPlayer.new
    computer = ComputerPlayer.new(@game_board.size * @game_board.pair_size)
    @players << computer
  end

  def switch_players!
    @players[0], @players[1] = @players[1], @players[0]
  end

  def take_turn
    show_board
    showing = []

    (1..@game_board.pair_size).each do

      player_guess = get_valid_guess
      showing << (player_guess)
      @game_board[showing.last].reveal
      show_board
      @players.each do |player|
        if player.is_a?(ComputerPlayer)
          player.peak_board(@game_board)
        end
      end

    end

    re_hide(showing) unless showing.map{|el| @game_board[el].face_value}.uniq.count == 1

    gets.chomp
    switch_players!
  end

  def get_valid_guess
    pg = 0
    until valid_guess?(pg)
      @players[0].prompt
      pg = @players[0].get_guess(@game_board)
    end

    pg - 1
  end


  def re_hide(cards)


      cards.each do |card|
        @game_board[card].hide
      end
  end

  def show_board
    system('clear')
    game_board.render
  end




  def valid_guess?(guess)
    # p game_board.size*@game_board.pair_size
    # p @game_board[guess].hidden
      guess.between?(1, @game_board.size*@game_board.pair_size) && @game_board[guess - 1].hidden
  end

  def play_game
    # debugger
    take_turn until game_over?
    puts "You win!"
  end

  def game_over?
    @game_board.won?
  end

end


a = Game.new
a.play_game
