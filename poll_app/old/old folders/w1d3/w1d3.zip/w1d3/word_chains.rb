require 'set'
require 'byebug'
class WordChainer
  attr_reader :dictionary
  attr_accessor :current_words, :all_seen_words

  def initialize(dict_file_name = 'dictionary.txt')
    @current_words = []
    @all_seen_words = []
    @dictionary = Set.new
    File.readlines(dict_file_name).each do |line|
      @dictionary.add(line.chomp)
    end
  end


  def adjacent_words(word)
    @dictionary.to_a.select{|wrd| one_off?(wrd,word)}
  end

  def one_off?(word1, word2)
    return false if word1.length != word2.length
    idx = 0
    tally = 0

    word1.each_char do |char|
      tally +=1 unless char == word2[idx]
      idx += 1
    end
    tally == 1
  end


  def run(source, target)
    # debugger
    @current_words = [source]
    @all_seen_words = [source]
    while @current_words.length > 0
      new_current_words = []
      @current_words.each do |word|
        # p @current_words
        # p adjacent_words(word+"")
        # p @all_seen_words
        adjacent_words(word+"").each do |aword|
          next if @all_seen_words.include?(aword)
          new_current_words << aword
          @all_seen_words << aword

        end

      end
      @current_words = new_current_words
    end
  p @all_seen_words

  end
end
a = WordChainer.new
puts "run"
p a.run("microscope","cap")
