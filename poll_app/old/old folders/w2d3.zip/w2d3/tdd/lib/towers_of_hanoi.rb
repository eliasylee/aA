class Towers
  attr_accessor :board

  def initialize
    @board = Array.new(3) { [] }
    populate
  end

  def move(start_end)

    start_stack, dest_stack = start_end
    start_stack = board[start_stack]
    dest_stack = board[dest_stack]


    if start_stack.empty?
      raise "Invalid move"
    elsif dest_stack.empty?
      move_disc(start_stack, dest_stack)
    elsif dest_stack.first < start_stack.first
      raise "Invalid move"
    else
      move_disc(start_stack, dest_stack)
    end
  end

  def play_game
    until won?
      begin
        system("clear")
        render_board
        puts "whats yer move? ex: x,y"
        input = parse_input(gets.chomp)
        move(input)

      rescue
        puts "your input was bad and you should feel bad"
        sleep(2)
        retry
      end
    end
    "you won the game!"
  end
  
  def won?
    @board[2].count == 3
  end

  private

  def populate
    @board[0] = [1, 2, 3]
  end


  def parse_input(input)
    input.split(",").map(&:to_i)
  end


  def move_disc(start_stack, dest_stack)
    disc_to_move = start_stack.shift
    dest_stack.unshift(disc_to_move)
  end

  def render_board
    p @board
  end

end
