def remove_dups(array)
  un_duped = []
  array.each do |el|
    un_duped << el unless un_duped.include?(el)
  end
  un_duped
end

class Array
  def two_sum
    pairs = []

    (0...self.length).each do |i|
      ((i + 1)...self.length).each do |j|
        pairs << [i, j] if self[i] + self[j] == 0
      end
    end
    pairs
  end
end

def my_transpose(array)
  transposed = Array.new(array.length) { [] }
  (0...array.length).each do |i|
    (0...array.length).each do |j|
      transposed[i] << array[j][i]
    end
  end
  transposed
end

def stock_picker(array)
  best_day = [0, 1]

  (0...array.length).each do |i|
    ((i + 1)...array.length).each do |j|
      if array[j] - array[i] > array[best_day.last] - array[best_day.first]
        best_day = [i, j]
      end
    end
  end
  best_day
end
