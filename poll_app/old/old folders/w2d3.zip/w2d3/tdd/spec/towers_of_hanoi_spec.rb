require 'towers_of_hanoi'

describe Towers do
  let(:towers) { Towers.new }

  describe '#initialize' do
    it "creates an array of three arrays" do
      expect(towers.board.count).to eq(3)
    end

    it "populates the arrays correctly" do
      expect(towers.board).to eq([[1, 2, 3], [], []])
    end
  end

  describe '#move' do
    before(:each) do
      towers.move([0, 1])
    end

    it "removes specific disc from existing stack" do
      expect(towers.board[0]).to eq([2, 3])
    end

    it "adds disc to destination stack" do
      expect(towers.board[1]).to eq([1])
    end

    it "does not move a larger disc onto a smaller disc" do
      expect{ towers.move([0, 1]) }.to raise_error("Invalid move")
    end

    it "cannot access private helper methods" do
      expect{ towers.move_disc }.to raise_error(NoMethodError)
    end
  end

  describe '#won' do
    before(:each) do
      towers.board = [[], [], [1, 2, 3]]
    end

    it "recognizes the winning board state" do
      expect(towers.won?).to eq(true)
    end
  end
end
