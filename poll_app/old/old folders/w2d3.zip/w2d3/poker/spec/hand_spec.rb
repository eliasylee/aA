require 'hand'

describe Hand do
  subject(:h) { Hand.new }

  describe '#best_hand'
    it "finds the best hand" do
      h.hand = [Card.new(2, :spades),
                Card.new(6, :spades),
                Card.new(10, :spades),
                Card.new(2, :spades),
                Card.new(3, :spades)]
      expect(h.best_hand).to eq(10)
    end

  # before(:each) do
  #   h.hand = [Card.new(2, :hearts),
  #             Card.new(6, :clubs),
  #             Card.new(6, :hearts),
  #             Card.new(2, :diamonds),
  #             Card.new(3, :spades)]
  # end
  #
  # describe '#pair?'
  #   it "finds a pair" do
  #     expect(h.pair?).to eq(6)
  #   end
  #
  #   it "returns nil if no pair" do
  #     h.hand.shift(2)
  #     expect(h.pair?).to eq(nil)
  #   end
  #
  #   it "returns highest pair" do
  #     expect(h.pair?).to eq(6)
  #   end
  #
  #   describe '#two_pair?'
  #     it "finds two pair and returns highest pair" do
  #       expect(h.two_pair?).to eq(6)
  #     end
  #
  #     it "returns nil if not two pair" do
  #       h.hand.shift(2)
  #       expect(h.two_pair?).to eq(nil)
  #     end
  #
  #   describe '#three_of_a_kind?'
  #     it "finds three of a kind and returns value" do
  #       h.hand.pop
  #       h.hand.push(Card.new(6, :diamonds))
  #       expect(h.three_of_a_kind?).to eq(6)
  #     end
  #
  #     it "returns nil if not three of a kind" do
  #       expect(h.three_of_a_kind?).to eq(nil)
  #     end
  #
  #   describe '#straight?'
  #     it "finds 5 consecutive values" do
  #       h.hand = [Card.new(2, :hearts),
  #                 Card.new(4, :clubs),
  #                 Card.new(6, :hearts),
  #                 Card.new(5, :diamonds),
  #                 Card.new(3, :spades)]
  #       expect(h.straight?).to eq(6)
  #     end
  #
  #     it "returns nil if not a straight" do
  #       expect(h.straight?).to eq(nil)
  #     end
  #
  #   describe '#flush?'
  #     it "finds 5 of same suit" do
  #       h.hand = [Card.new(2, :hearts),
  #                 Card.new(6, :hearts),
  #                 Card.new(10, :hearts),
  #                 Card.new(8, :hearts),
  #                 Card.new(4, :hearts)]
  #       expect(h.flush?).to eq(10)
  #     end
  #
  #     it "returns nil if not flush" do
  #       expect(h.flush?).to eq(nil)
  #     end
  #
  #   describe '#full_house?'
  #     it "finds three of a kind, and one pair" do
  #       h.hand.pop
  #       h.hand.push(Card.new(6, :spades))
  #       expect(h.full_house?).to eq(6)
  #     end
  #
  #     it "returns nil if not a full house" do
  #       expect(h.full_house?).to eq(nil)
  #     end
  #
  #   describe '#four_of_a_kind?'
  #     it "finds four of a king" do
  #       h.hand.pop(2)
  #       2.times { h.hand.push(Card.new(6, :diamonds)) }
  #       expect(h.four_of_a_kind?).to eq(6)
  #     end
  #
  #     it "returns nil if not four of a kind" do
  #       expect(h.four_of_a_kind?).to eq(nil)
  #     end
  #
  #   describe '#straight_flush?'
  #     it "finds a straight flush and returns highest value" do
  #       h.hand = [Card.new(5, :hearts),
  #                 Card.new(6, :hearts),
  #                 Card.new(8, :hearts),
  #                 Card.new(7, :hearts),
  #                 Card.new(9, :hearts)]
  #       expect(h.straight_flush?).to eq(9)
  #     end
  #
  #     it "doesn't find things that aren't there on tuesdays" do
  #       expect(h.straight_flush?).to eq(nil)
  #     end

end
