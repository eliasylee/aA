require 'card'

describe Card do
  subject(:card) { Card.new(2, :hearts) }

  it "has a value" do
    expect(card.value).to eq(2)
  end

  it "has a suit" do
    expect(card.suit).to eq(:hearts)
  end

  it "has a face" do
    expect(card.face).to eq("2 of ♥")
  end
end
