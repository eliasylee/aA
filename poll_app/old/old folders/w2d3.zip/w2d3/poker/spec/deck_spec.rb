require 'deck'

describe Deck do
  subject(:deck) { Deck.new }

  describe "#initialize"
    it "populates 52 cards" do
      expect(deck.deck.count).to eq(52)
    end

    it "populates each card only once" do
      expect(deck.deck.uniq).to eq(deck.deck)
    end

  describe "#deal"
    it "returns top card from deck" do
      first_card = deck.deck.first
      expect(deck.deal).to eq(first_card)
    end

    it "removes card from deck" do
      deck.deal
      expect(deck.deck.count).to eq(51)
    end

  describe "#shuffle"
    it "randomizes order of cards" do
      unshuffled = Deck.new
      expect(deck.shuffle).to_not eq(unshuffled)
    end

end
