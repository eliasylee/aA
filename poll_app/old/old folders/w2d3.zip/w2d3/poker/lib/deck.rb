class Deck
  attr_reader :deck

  def initialize
    @deck = create_standard_deck
  end

  def deal
    @deck.shift
  end

  def shuffle
    @deck.shuffle!
  end

  private

  def create_standard_deck
    deck = []
    suits = [:hearts, :diamonds, :spades, :clubs]

    suits.each do |suit|
      (2..14).each do |value|
        deck << Card.new(value, suit)
      end
    end

    deck
  end

end
