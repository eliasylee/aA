class Hand
  attr_accessor :hand

  def initialize
    @hand = []
  end

  def best_hand
    return straight_flush? if straight_flush?
    return four_of_a_kind? if four_of_a_kind?
    return full_house? if full_house?
    return flush? if flush?
    return straight? if straight?
    return three_of_a_kind? if three_of_a_kind?
    return two_pair? if two_pair?
    return pair? if pair?
    hand.max
  end

  private

  def pair?
    values_in_hand = @hand.map { |card| card.value }
    pairs = values_in_hand.select { |v| values_in_hand.count(v) == 2 }

    pairs.max || nil
  end

  def two_pair?
    values_in_hand = @hand.map { |card| card.value }
    pairs = values_in_hand.select { |v| values_in_hand.count(v) == 2 }

    pairs.count == 4 ? pairs.max : nil
  end

  def three_of_a_kind?
    values_in_hand = @hand.map { |card| card.value }
    triplet = values_in_hand.select { |v| values_in_hand.count(v) == 3 }

    triplet.first || nil
  end

  def straight?
    values_in_hand = @hand.map { |card| card.value }
    low = values_in_hand.min
    high = values_in_hand.max
    return nil unless (low..high).to_a == values_in_hand.uniq.sort

    high
  end

  def flush?
    suits_in_hand = @hand.map { |card| card.suit }
    values_in_hand = @hand.map { |card| card.value }
    return nil unless suits_in_hand.uniq.count == 1

    values_in_hand.max
  end

  def full_house?
    values_in_hand = @hand.map { |card| card.value }
    pair? && three_of_a_kind? ? three_of_a_kind? : nil
  end

  def four_of_a_kind?
    values_in_hand = @hand.map { |card| card.value }
    quartet = values_in_hand.select { |v| values_in_hand.count(v) == 4 }

    quartet.first || nil
  end

  def straight_flush?
    suits_in_hand = @hand.map { |card| card.suit }
    values_in_hand = @hand.map { |card| card.value }
    straight? && flush? ? straight? : nil
  end
end
