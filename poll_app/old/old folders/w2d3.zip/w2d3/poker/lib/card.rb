class Card
  SUIT_HASH = {
    :hearts => '♥',
    :diamonds => '♦',
    :clubs => '♣',
    :spades => '♠'
  }

  attr_reader :value, :suit, :face

  def initialize(value, suit)
    @value = value
    @suit = suit
    @face = get_face
  end

  private

  def get_face
    "#{value} of #{SUIT_HASH[suit]}"
  end
end
